SELECT COUNT(*)
FROM user
WHERE location = "New York";